const express = require('express');
const router = express.Router();
const userController = require("../Controller/userController.js");

router.post('/register/new', userController.registerNewUser);
router.put('/:id/role', userController.updateUserRole);
router.get('/list', userController.getUserList);
router.put('/:id/password', userController.updateUserPassword);
router.delete('/:id', userController.deleteUser);


module.exports = router;
