const User=require("../Models/userModel.js");

exports.registerNewUser = async (req, res) => {
  try {
    const { fullname, email, username, password } = req.body;

   
    if (!fullname || !email || !username || !password) {
      return res.status(400).send('All fields are required');
    }

    if (fullname.length < 3 || fullname.length > 50 ||
        username.length < 3 || username.length > 20 ||
        password.length < 6 || password.length > 20) {
      return res.status(400).send('Validation failed: check field lengths');
    }

    const emailExists = await User.findOne({ email });
    if (emailExists) return res.status(400).send('Email already exists');

    const usernameExists = await User.findOne({ username });
    if (usernameExists) return res.status(400).send('Username already exists');

    const newUser = new User({ fullname, email, username, password });
    await newUser.save();

    res.send('User registered successfully!');
  } catch (err) {
    res.status(500).send('Server error: ' + err.message);
  }
};
exports.updateUserRole = async (req, res) => {
    try {
        const { id } = req.params;
        const { role, currentUserRole } = req.body;

        // Check if current user is Admin (for now, we just check the sent body)
        if (currentUserRole !== 'Admin') {
            return res.status(403).json({ message: 'Access denied. Only Admin can assign roles.' });
        }

        // Check if target role is valid
        if (!['Admin', 'Customer', 'Salesman'].includes(role)) {
            return res.status(400).json({ message: 'Invalid role provided.' });
        }

        const user = await user.findByIdAndUpdate(
            id,
            { role },
            { new: true }
        );

        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        res.json({ message: 'User role updated successfully.', user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error.' });
    }
};
exports.getUserList = async (req, res) => {
    try {
        const users = await User.find().select('-password'); // exclude password
        res.json({ users });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error.' });
    }
};
const bcrypt = require('bcrypt');

exports.updateUserPassword = async (req, res) => {
    try {
        const userId = req.params.id;
        const { password } = req.body;

        if (!password || password.length < 6 || password.length > 20) {
            return res.status(400).json({ message: 'Password must be 6-20 characters.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const updatedUser = await User.findByIdAndUpdate(userId, { password: hashedPassword }, { new: true });

        if (!updatedUser) {
            return res.status(404).json({ message: 'User not found.' });
        }

        res.json({ message: 'Password updated successfully!' });
    } catch (error) {
        res.status(500).json({ message: 'Server error: ' + error.message });
    }
};
exports.deleteUser = async (req, res) => {
    try {
        const userId = req.params.id;

        const deletedUser = await User.findByIdAndDelete(userId);

        if (!deletedUser) {
            return res.status(404).json({ message: 'User not found.' });
        }

        res.json({ message: 'User deleted successfully!' });
    } catch (error) {
        res.status(500).json({ message: 'Server error: ' + error.message });
    }
};

