const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const userRoutes = require('./routes/UserRouter.js');
const PORT = 8000;
const host='localhost';
const path = require('path');


const db_connection = require('./config/database.js');
db_connection();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/users/list', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'userList.html'));
});

app.get('/', (req, res) => {
   // res.send('Welcome to the Restaurant Management System API!');
   res.sendFile(path.join(__dirname, 'views', 'registration.html'));
});
app.use('/api/users', userRoutes);

app.get('/registration.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'registration.html'));
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
