function db_connection() {
    const db = require("mongoose");
    db.connect('mongodb://127.0.0.1:27017/test')
    .then(() => {
        console.log(" MongoDB connected");
    })
    .catch((err) => {
        console.error("MongoDB connection error:", err);
    });
}

module.exports = db_connection;
