# Restaurant Management System (RMS) — User Module

This project implements a user management module for a Restaurant Management System using **Node.js, Express, MongoDB, and Mongoose**. It follows the MVC architecture and includes features like user registration, role management, password updates, user listing, and deletion.

---

## ✨ Features

- ✅ User Registration with validation
- ✅ Role-Based Access Control (Admin, Customer, Salesman)
- ✅ View User List (JSON + HTML table)
- ✅ Update User Password (with bcrypt hashing)
- ✅ Delete User

---

## 💾 Requirements

- Node.js + npm
- MongoDB Community Server
- Postman (for API testing)
- MongoDB Compass (for visual DB inspection)

---

## 📦 Setup Instructions

1. Clone or download the project.
2. Install dependencies:
   ```bash
   npm install
