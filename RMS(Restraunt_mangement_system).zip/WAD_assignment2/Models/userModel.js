const mongoose=require('mongoose');

const userSchema=mongoose.Schema({
    fullname:{
        type: String,
        required: true,
        minlength: 3, 
        maxlength: 50
    },
    email:{
     type: String, 
     required: true, 
     unique: true },
    username: { 
    type: String, 
    required: true, 
    unique: true, 
    minlength: 3, 
    maxlength: 20 },
    password: { 
    type: String, 
    required: true, 
    minlength: 6, 
    maxlength: 20 },
    role: { 
    type: String,
    enum: ['Admin', 'Customer', 'Salesman'],
    default: 'Customer' }
})
module.exports=mongoose.model('User',userSchema);